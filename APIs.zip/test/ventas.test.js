const assert = require('assert');

const ventasModel = require('../modelos/ventas/ventasModel');
//const { expect } = await import('chai');


//const ventas = require("../modelos/ventas/ventasModel.js");


(async () => {
    const { expect } = await import('chai');
    
    describe('Pruebas de la API ventas', () => {
        it('Obtención de lista de objetos', async () => {
            const result = await ventasModel.obtenerTodo();
            expect(result).to.be.an('array');
            expect(result[0]).to.be.an('object');
        });
    });
})();
