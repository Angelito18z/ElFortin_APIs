const express = require("express");
const ProveedorControlador = require ("../../controladores/proveedores/proveedorControlador");

const router = express.Router();

router.get('/proveedores/buscar/:q',ProveedorControlador.buscarProveedoresFiltro);
router.get('/proveedores/descargarExcel', ProveedorControlador.descargarProveedoresExcel);
router.get('/proveedores/:id',ProveedorControlador.obtenerProveedorPorId);

router.get('/proveedores', ProveedorControlador.obtenerProveedores);
router.post('/proveedores', ProveedorControlador.crearProveedor);
router.put('/proveedores/:id',ProveedorControlador.actualizarProveedor);
router.delete('/proveedores/:id',ProveedorControlador.borrarProveedor);

module.exports = router;