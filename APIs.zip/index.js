const express = require("express"); // Importa el framework Express
const proveedorRutas = require("../APIs/rutas/proveedores/proveedorRuta"); // Importa las rutas de productos
const orderRoutes = require('./rutas/pedidos/pedidosRoutes');
const restauranteRutas = require('./rutas/restaurantes/restauranteRutas') ;
const promocionRutas = require('./rutas/promociones/promocionRuta')
const ventaRutas = require('./rutas/ventas/ventasRoutes');
const productoRutas = require('./rutas/productos/productRoutes');
const usuarioRutas = require("./rutas/usuarios/usuariosRutas");

require("dotenv").config(); // Carga las variables de entorno desde el archivo .env

const app = express(); // Crea una instancia de la aplicación Express
app.use(express.json()); // Middleware para parsear el cuerpo de las solicitudes JSON

// Usa las rutas de productos con el prefijo "/api"
app.use("/api", proveedorRutas);
app.use("/api",orderRoutes);
app.use("/api",restauranteRutas);
app.use("/api",promocionRutas);
app.use("/api",ventaRutas);
app.use("/api",productoRutas);
app.use("/api",usuarioRutas);


// Inicia el servidor y escucha en el puerto definido
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`); // Muestra un mensaje en la consola indicando que el servidor está corriendo

});
